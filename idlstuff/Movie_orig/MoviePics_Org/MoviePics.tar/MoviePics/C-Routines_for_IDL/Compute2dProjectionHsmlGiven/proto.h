

void make_map(void);
